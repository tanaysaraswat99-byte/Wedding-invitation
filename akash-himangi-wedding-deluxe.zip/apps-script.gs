function doPost(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  const data = JSON.parse(e.postData.contents || '{}');
  if (sheet.getLastRow() === 0) sheet.appendRow(['Timestamp','Name','Attendance','Guests','Note']);
  sheet.appendRow([new Date(), data.name || '', data.attendance || '', data.guests || '', data.note || '']);
  return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
}