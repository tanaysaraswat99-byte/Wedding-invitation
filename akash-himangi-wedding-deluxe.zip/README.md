# Akash & Himangi — deluxe wedding invitation

## Included
- Animated split-curtain reveal, invitation seal, botanical sage/ivory theme
- Responsive sections, countdown, event cards, photo gallery, Google Maps search
- Optional background music toggle
- RSVP form with optional Google Sheets / Apps Script endpoint

## Preview
Open `index.html` in a browser. Internet is required for Google Fonts and the sample Unsplash images.

## Add your own couple photos
Replace the three image URLs in the `#gallery` section with your own hosted image URLs. For local files, create `assets/photos/`, place images there, and use paths such as `assets/photos/photo-1.jpg`.

## Add optional music
Place a royalty-free or personally licensed MP3 named `music.mp3` inside `assets/`. The music button appears after the guest opens the invitation. Browsers require a user gesture before audio can play.

## Enable RSVP collection
1. Create a Google Sheet.
2. Open Extensions → Apps Script.
3. Paste `apps-script.gs` and save.
4. Deploy → New deployment → Web app. Execute as: Me. Choose access appropriate for your guests (often Anyone), then authorize.
5. Copy the deployed URL ending `/exec`.
6. In `index.html`, replace `const RSVP_ENDPOINT=''` with `const RSVP_ENDPOINT='YOUR_WEB_APP_URL'`.
7. Re-upload the updated project and test a submission by checking the Sheet.
The form uses `no-cors`, so the browser cannot read a response; verify entries in the Sheet. Keep the Sheet private.

## Publish a shareable link
1. Visit https://app.netlify.com/drop and sign in.
2. Upload the unzipped project folder (the folder containing `index.html`).
3. Netlify provides a public `*.netlify.app` URL.
4. Test the link on a phone, then share it on WhatsApp.
You can rename the site in Netlify or connect a domain you own.

## Details still to confirm
The exact venue/address, timings and other event dates were not provided, so they are marked as pending. Countdown currently targets 6:00 PM IST on 11 Feb 2027 as a placeholder; update `weddingAt` when the ceremony time is known. Replace sample gallery photos with Akash and Himangi's own images before sharing.
